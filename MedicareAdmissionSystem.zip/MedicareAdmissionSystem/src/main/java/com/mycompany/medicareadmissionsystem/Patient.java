/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.medicareadmissionsystem;

/**
 *
 * @author Student
 */
public class Patient {
    private String patientId;
    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private String medicalCondition;
    private PatientCategory category; // enum

    public Patient(String id, String fName, String lName, int age, String gender, String condition, PatientCategory category) {
        this.patientId = id;
        this.firstName = fName;
        this.lastName = lName;
        this.age = age;
        this.gender = gender;
        this.medicalCondition = condition;
        this.category = category;
    }

    // Getters & Setters
    public String getPatientId() { return patientId; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
    public String getMedicalCondition() { return medicalCondition; }
    public PatientCategory getCategory() { return category; }

    public void setFirstName(String fName) { this.firstName = fName; }
    public void setLastName(String lName) { this.lastName = lName; }
    public void setAge(int age) { this.age = age; }
    public void setGender(String gender) { this.gender = gender; }
    public void setMedicalCondition(String condition) { this.medicalCondition = condition; }
    public void setCategory(PatientCategory category) { this.category = category; }

    @Override
    public String toString() {
        return "PATIENT ID: " + patientId + "\n" +
               "NAME: " + firstName + " " + lastName + "\n" +
               "AGE: " + age + "\n" +
               "GENDER: " + gender + "\n" +
               "CONDITION: " + medicalCondition + "\n" +
               "CATEGORY: " + category + "\n";
    }
}
   

