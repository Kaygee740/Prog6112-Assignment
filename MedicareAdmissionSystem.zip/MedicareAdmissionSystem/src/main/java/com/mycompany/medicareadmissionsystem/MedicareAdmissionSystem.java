/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.medicareadmissionsystem;

/**
 *
 * @author Student
 */
public class MedicareAdmissionSystem {

    public static void main(String[] args) {
        HospitalSystem hs = new HospitalSystem();
        java.util.Scanner input = new java.util.Scanner(System.in);

        while (true) {
            System.out.println("=== MEDICARE ADMISSION SYSTEM ===");
            System.out.println("(1) Register Patient");
            System.out.println("(2) Search Patient");
            System.out.println("(3) Update Patient");
            System.out.println("(4) Delete Patient");
            System.out.println("(5) Allocate Bed");
            System.out.println("(6) Release Bed");
            System.out.println("(7) Reports");
            System.out.println("(8) Exit");

            int choice = Integer.parseInt(input.nextLine());

            switch (choice) {
                case 1 -> hs.registerPatient();
                case 2 -> hs.searchPatient();
                case 3 -> hs.updatePatient();
                case 4 -> hs.deletePatient();
                case 5 -> hs.allocateBed();
                case 6 -> hs.releaseBed();
                case 7 -> hs.generateReports();
                case 8 -> {
                    System.out.println(" Goodbye!"); return;
                }
                default -> System.out.println(" Invalid option!");
            }
        }
    }
}
    

