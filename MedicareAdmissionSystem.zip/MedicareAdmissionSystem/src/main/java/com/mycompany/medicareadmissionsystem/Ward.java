/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.medicareadmissionsystem;

import java.util.ArrayList;

/**
 *
 * @author Student
 */
public class Ward {
    private ArrayList<Bed> beds = new ArrayList<>();

    public Ward() {
        // Initialize 20 beds
        for (int i = 1; i <= 20; i++) {
            beds.add(new Bed("B" + String.format("%02d", i)));
        }
    }

    public ArrayList<Bed> getBeds() { return beds; }

    public void displayWardLayout() {
        for (Bed b : beds) {
            System.out.println(b.toString());
        }
    }

    public Bed findAvailableBed() {
        for (Bed b : beds) {
            if (!b.isOccupied()) return b;
        }
        return null; // no beds available
    }
}
   

