/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.medicareadmissionsystem;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class HospitalSystem {
    private ArrayList<Patient> patients = new ArrayList<>();
    private Ward ward = new Ward();
    private Scanner input = new Scanner(System.in);

    // Register patient
    public void registerPatient() {
        System.out.print("Enter Patient ID: ");
        String id = input.nextLine();

        System.out.print("First Name: ");
        String fName = input.nextLine();

        System.out.print("Last Name: ");
        String lName = input.nextLine();

        System.out.print("Age: ");
        int age = Integer.parseInt(input.nextLine());

        System.out.print("Gender: ");
        String gender = input.nextLine();

        System.out.print("Medical Condition: ");
        String condition = input.nextLine();

        System.out.print("Category (INPATIENT/OUTPATIENT/EMERGENCY): ");
        PatientCategory category = PatientCategory.valueOf(input.nextLine().toUpperCase());

        Patient p = new Patient(id, fName, lName, age, gender, condition, category);
        patients.add(p);

        System.out.println("✅ Patient registered successfully!");
    }

    // Search patient
    public void searchPatient() {
        System.out.print("Enter Patient ID to search: ");
        String id = input.nextLine();
        for (Patient p : patients) {
            if (p.getPatientId().equals(id)) {
                System.out.println(p.toString());
                return;
            }
        }
        System.out.println("⚠️ Patient not found!");
    }

    // Update patient
    public void updatePatient() {
        System.out.print("Enter Patient ID to update: ");
        String id = input.nextLine();
        for (Patient p : patients) {
            if (p.getPatientId().equals(id)) {
                System.out.print("New First Name: ");
                p.setFirstName(input.nextLine());
                System.out.print("New Last Name: ");
                p.setLastName(input.nextLine());
                System.out.print("New Age: ");
                p.setAge(Integer.parseInt(input.nextLine()));
                System.out.print("New Gender: ");
                p.setGender(input.nextLine());
                System.out.print("New Condition: ");
                p.setMedicalCondition(input.nextLine());
                System.out.println("✅ Patient updated successfully!");
                return;
            }
        }
        System.out.println("⚠️ Patient not found!");
    }

    // Delete patient
    public void deletePatient() {
        System.out.print("Enter Patient ID to delete: ");
        String id = input.nextLine();
        patients.removeIf(p -> p.getPatientId().equals(id));
        System.out.println("🗑️ Patient deleted if existed.");
    }

    // Allocate bed
    public void allocateBed() {
        System.out.print("Enter Patient ID to allocate bed: ");
        String id = input.nextLine();
        for (Patient p : patients) {
            if (p.getPatientId().equals(id) && p.getCategory() == PatientCategory.INPATIENT) {
                Bed available = ward.findAvailableBed();
                if (available != null) {
                    available.allocateBed(p);
                    System.out.println("✅ Bed " + available.getBedId() + " allocated to " + p.getFirstName());
                } else {
                    System.out.println("⚠️ No beds available!");
                }
                return;
            }
        }
        System.out.println("⚠️ Patient not found or not an inpatient!");
    }

    // Release bed
    public void releaseBed() {
        System.out.print("Enter Bed ID to release: ");
        String id = input.nextLine();
        for (Bed b : ward.getBeds()) {
            if (b.getBedId().equals(id) && b.isOccupied()) {
                b.releaseBed();
                System.out.println("✅ Bed " + id + " released!");
                return;
            }
        }
        System.out.println("⚠️ Bed not found or already free!");
    }

    // Reports
    public void generateReports() {
        System.out.println("=== REPORTS ===");
        System.out.println("Total Patients: " + patients.size());
        long occupiedBeds = ward.getBeds().stream().filter(Bed::isOccupied).count();
        System.out.println("Occupied Beds: " + occupiedBeds);
        System.out.println("Available Beds: " + (20 - occupiedBeds));
        double occupancy = (occupiedBeds / 20.0) * 100;
        System.out.println("Ward Occupancy: " + occupancy + "%");
    }
} 

