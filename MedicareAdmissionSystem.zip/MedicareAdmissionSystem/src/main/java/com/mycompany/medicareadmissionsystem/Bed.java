/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.medicareadmissionsystem;

/**
 *
 * @author Student
 */
public class Bed {
    private String bedId;
    private boolean occupied;
    private Patient patient;

    public Bed(String bedId) {
        this.bedId = bedId;
        this.occupied = false;
        this.patient = null;
    }

    public String getBedId() { return bedId; }
    public boolean isOccupied() { return occupied; }
    public Patient getPatient() { return patient; }

    public void allocateBed(Patient p) {
        this.patient = p;
        this.occupied = true;
    }

    public void releaseBed() {
        this.patient = null;
        this.occupied = false;
    }

    @Override
    public String toString() {
        if (occupied) {
            return bedId + " → Occupied by " + patient.getFirstName() + " " + patient.getLastName();
        } else {
            return bedId + " → Available";
        }
    }
}
   

